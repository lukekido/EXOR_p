// window_haze.frag: the film of grime and haze on an interior's window (bible 10,
// "Cleaner": once a week each place's windows fog over, and the cleaner makes them clear).
//
// The pane under it has just been drawn: either the city seen through it (a window with a
// camera: its picture of this frame, window_view.frag) or the plain glass of daylight.
// This face lies 4 mm in front of it, on the room's side, and draws the haze over it:
//   - the VEIL: a milky film, lit by the room's lamps and, by day, by the daylight that
//     comes through the glass and scatters in it. Never opaque: the street still shows,
//     washed out;
//   - over a window with the city behind it, the city is also BLURRED: a frosted glass
//     spreads each point of what lies beyond into a small disc. The picture of the city is
//     read again around each pixel (the same picture the pane shows) and averaged, over a
//     disc that grows with the haze and shrinks with the distance to the glass;
//   - the film is not even: a soft cloudy pattern fixed on the glass, a little thicker
//     toward the sill (where the damp and the dust settle), with faint vertical runs;
//   - the SQUEEGEE: while the cleaner works on it, a clear band sweeps from one side of
//     the window to the other (u_wipe, 0 to 1).

in vec3 v_world_position;
in vec3 v_normal;
in vec2 v_pane;   // where on the glass, meters from its lower corner
in vec2 v_size;   // the glass's width and height, meters

uniform float u_haze;          // 0 clear ... 1 the whole film
uniform float u_wipe;          // the squeegee's sweep, 0 ... 1 (0: not cleaning it)
uniform vec3 u_veil;           // the film's color, lit (the room's lamps, the daylight)
uniform int u_has_view;        // 1: the city's picture is behind (u_view), 0: plain glass
uniform sampler2D u_view;      // that picture, this frame
uniform vec4 u_rect;           // the picture's drawn rectangle (x, y, width, height), pixels
uniform float u_blur;          // pixels of blur for a full haze, one meter from the glass
uniform float u_glow_share;    // the halos' share outdoors over indoors (window_view.frag)

out vec4 frag_color;

float hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}
float noise(vec2 p) {
    vec2 i = floor(p), f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), u.x), mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), u.x), u.y);
}

// Twelve points of a disc of radius 1, spread evenly (a Poisson-like set).
const vec2 taps[12] = vec2[12](vec2(-0.326, -0.406), vec2(-0.840, -0.074), vec2(-0.696, 0.457), vec2(-0.203, 0.621), vec2(0.962, -0.195),
                               vec2(0.473, -0.480), vec2(0.519, 0.767), vec2(0.185, -0.893), vec2(0.507, 0.064), vec2(0.896, 0.412),
                               vec2(-0.322, -0.933), vec2(-0.792, -0.598));

void main() {
    // The film's thickness here: the cloudy pattern (two octaves, ~16 cm and ~6 cm), the
    // damp toward the sill, the runs.
    vec2 p = v_pane;
    float cloud = 0.65 * noise(p * 6.0) + 0.35 * noise(p * 16.0 + 7.3);
    float sill = 1.0 - clamp(p.y / max(v_size.y, 0.01), 0.0, 1.0);
    float runs = noise(vec2(p.x * 28.0, p.y * 1.3));
    // The squeegee: the glass behind its sweep is clear (a soft edge, 3% of the width).
    float across = p.x / max(v_size.x, 0.01);
    float left = u_wipe > 0.0 ? smoothstep(u_wipe - 0.03, u_wipe + 0.03, across) : 1.0;
    float haze = u_haze * left;
    float film = haze * clamp(0.62 + 0.55 * cloud + 0.30 * sill * sill + 0.06 * runs, 0.0, 1.4);
    float veil = clamp(0.62 * film, 0.0, 0.8);

    if (u_has_view == 1) {
        // The city behind, blurred over a disc: wider for a thicker film and a nearer glass
        // (gl_FragCoord.w is one over the distance along the view).
        // (The haze's even share, not the film's pattern: a patterned blur streaks.)
        float radius = min(u_blur * haze * gl_FragCoord.w, 16.0);
        vec2 lo = u_rect.xy, hi = u_rect.xy + u_rect.zw - vec2(1.0);
        vec4 sum = texelFetch(u_view, ivec2(gl_FragCoord.xy), 0);
        for (int i = 0; i < 12; ++i) {
            sum += texelFetch(u_view, ivec2(clamp(gl_FragCoord.xy + taps[i] * radius, lo, hi)), 0);
        }
        vec4 city = sum / 13.0;
        // Opaque, like the pane: the blurred city under the veil. The glow mark (alpha) as
        // the pane's own, dimmed by the film: a street lamp halos less through dirty glass.
        frag_color = vec4(mix(city.rgb, u_veil, veil), city.a * u_glow_share * (1.0 - veil));
    } else {
        // Over the plain glass: blended (premultiplied), the veil over what is there.
        frag_color = vec4(u_veil * veil, veil);
    }
}
