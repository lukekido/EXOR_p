// glass.frag: a tinted window seen from inside a bus or a monorail car.
//
// From outside the windows are a black film (an opaque face, drawn with the vehicle).
// From inside, this face is drawn instead, LAST, after the whole world: whatever is
// already on screen behind it (the street, the sky, the other cars) shows through,
// a little darker. The game blends it as
//
//     on screen = this color + what was there x (1 - alpha)
//
// so alpha is how much of the world the glass swallows (its tint) and the color is what
// the glass adds on top (its reflection). Three touches make it read as glass, not as a
// hole in the wall:
//   - the TINT: alpha u_darken where the eye looks straight through;
//   - the REFLECTION (Fresnel): glass seen at a grazing angle reflects more and lets
//     less through, so the panes far down the car look shinier and darker than the one
//     at the passenger's shoulder;
//   - the RIM and a faint SHEEN: a darker band a few centimeters wide along the pane's
//     edges (where the film meets the seal), and two thin diagonal streaks of light,
//     fixed on the pane, so the glass has a surface the eye can find.

in vec3 v_world_position;
in vec3 v_normal;
in vec2 v_pane;
in vec2 v_size;

uniform vec3 u_camera_position;
uniform vec3 u_reflect;     // what the glass reflects: the sky's light by day, the car's lamps at night
uniform float u_darken;     // the tint: how much of the world it swallows, looking straight through
uniform vec2 u_fog_range;

out vec4 frag_color;

void main() {
    vec3 to_eye = normalize(u_camera_position - v_world_position);
    float facing = abs(dot(normalize(v_normal), to_eye));  // 1 straight on, 0 edge-on
    // Schlick's approximation of how glass reflects more toward grazing angles.
    float fresnel = pow(1.0 - facing, 5.0);

    // The rim: meters to the nearest edge of the pane.
    float edge = min(min(v_pane.x, v_size.x - v_pane.x), min(v_pane.y, v_size.y - v_pane.y));
    float rim = 1.0 - smoothstep(0.015, 0.05, edge);

    // The sheen: diagonal streaks every 2.4 m along the pane, a wide soft one and a thin
    // sharp one beside it.
    float d = fract((v_pane.x + v_pane.y * 0.7) / 2.4);
    float wide = (d - 0.5) / 0.035;
    float thin = (d - 0.42) / 0.012;
    float sheen = 0.6 * exp(-wide * wide) + 0.4 * exp(-thin * thin);

    float alpha = u_darken + (1.0 - u_darken) * 0.6 * fresnel;
    alpha = mix(alpha, 0.85, rim);
    vec3 light = u_reflect * (0.3 + 2.0 * fresnel + 0.8 * sheen) * (1.0 - rim);

    // Far away the fog takes it, like everything else (the glass fades to nothing).
    float fog = smoothstep(u_fog_range.x, u_fog_range.y, distance(v_world_position, u_camera_position));
    frag_color = vec4(light * (1.0 - fog), alpha * (1.0 - fog));
}
