// frame_scale.frag: the world's smaller picture stretched over the window (the render
// scale, render/frame_scale.hpp). The texture's own LINEAR filter blends the four
// nearest pixels; the alpha (what glows, for the bloom) is copied as it is.

in vec2 v_uv;

uniform sampler2D u_source;

out vec4 frag_color;

void main() {
    frag_color = texture(u_source, v_uv);
}
