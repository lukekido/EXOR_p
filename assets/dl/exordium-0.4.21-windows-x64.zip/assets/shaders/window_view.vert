// window_view.vert: an interior's window pane that shows the open world (see
// window_view.frag). The panes are plain quads in the interior's own place; only their
// position is used: the picture they show is read pixel for pixel from the screen.

layout(location = 0) in vec3 a_position;
layout(location = 1) in vec3 a_normal;
layout(location = 2) in vec3 a_color;
layout(location = 3) in float a_emissive;

uniform mat4 u_view_projection;

void main() {
    gl_Position = u_view_projection * vec4(a_position, 1.0);
}
