// sky.frag: WHERE EVERY PIXEL GETS A PRIVATE WEATHER FORECAST. For each pixel we ask
// "if you looked this way, what would the sky be doing?" and then we simply compute
// the correct answer, because this is a video game and reality ships separately.
// No skydome mesh, no cubemap gathering dust, no 4K panorama devouring VRAM: one
// shader performing a convincing impression of an atmosphere. No "#version": the
// game adds it.

in vec2 v_ndc;

uniform mat4 u_inverse_view_projection;  // THE TIME MACHINE: drags a screen pixel back
                                         // into the world, undoing everything the camera
                                         // did to it. Screen -> world, played in reverse.
uniform vec3 u_camera_position;          // the player's eyeballs, current coordinates.
                                         // That's it. That's the whole lore.
uniform vec3 u_horizon_color;            // IDENTICAL to the fog color: the ground
                                         // dissolves into the sky and nobody ever
                                         // finds the seam we never drew.
uniform vec3 u_zenith_color;             // straight up: the moodier, darker sibling.
                                         // All the drama lives above head height.
uniform vec3 u_sun_direction;            // where the sun is pointing its spotlight
uniform vec3 u_sun_color;                // what it charges for admission
uniform vec3 u_moon_direction;           // THE SUN, MOONLIGHTING: same dot-product
                                         // trick, worse shift hours, colder wardrobe.
uniform float u_night;                   // 0 by day, 1 at night: the night staff
                                         // punch in as this reaches 1.

out vec4 frag_color;

// A CHEAP PSEUDO-RANDOM NUMBER, mass-produced from a 3D cell: three fracts and a
// multiply, and the universe sells you randomness at a discount. Deterministic
// randomness -- yes, an oxymoron, and a load-bearing one: the same cell always
// gives the same value, so the stars stay exactly where we left them.
float hash(vec3 p) {
    p = fract(p * 0.3183099 + 0.1);
    p *= 17.0;
    return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
}

void main() {
    // WHERE ARE WE LOOKING? One matrix multiply undoes the whole camera, lands on the
    // far plane, we subtract the eye and normalize: a textbook ray direction,
    // assembled by playing the camera tape backwards. If you listen closely, the
    // hidden voices in the matrices are whispering something profound. It is
    // "normalize".
    vec4 far_point = u_inverse_view_projection * vec4(v_ndc, 1.0, 1.0);
    vec3 direction = normalize(far_point.xyz / far_point.w - u_camera_position);

    // THE ENTIRE ATMOSPHERE, ACQUIRED FOR ONE SMOOTHSTEP: horizon color at and below
    // the horizon, deepening toward the zenith -- one mix() and one smoothstep, and
    // the audience believes every pixel of it. Considerably cheaper than actual air.
    float up = max(direction.y, 0.0);
    vec3 color = mix(u_horizon_color, u_zenith_color, smoothstep(0.0, 0.55, up));

    // THE SUN: the real one is 1,392,700 km wide and runs on nuclear fusion. Ours is
    // a sharp disk (smoothstep) plus a soft glow (pow, exponent 48) and runs entirely
    // on mathematics. Advantage: ours never runs out of hydrogen. Disadvantage: none
    // detected at this distance.
    float facing_sun = max(dot(direction, u_sun_direction), 0.0);
    color += u_sun_color * (smoothstep(0.9992, 0.9996, facing_sun) * 3.0 + pow(facing_sun, 48.0) * 0.35);

    // NIGHT SHIFT, EVERYBODY OFF THE DAY ROSTER: the moon clocks in -- a very slightly
    // different smoothstep on a very slightly different schedule -- and the stars
    // file in one hash at a time, each cell of the direction grid rolling the dice
    // once while step() keeps only the top 0.25% of rolls. Note the smoothstep on
    // direction.y: stars strictly above the horizon, because buried glowing dots
    // would merely confuse the archaeologists of level design.
    float facing_moon = max(dot(direction, u_moon_direction), 0.0);
    color += vec3(0.85, 0.88, 0.95) * smoothstep(0.9993, 0.9996, facing_moon) * u_night;
    float star = step(0.9975, hash(floor(direction * 250.0)));
    color += vec3(0.8) * star * u_night * smoothstep(0.05, 0.25, direction.y);

    // AND CUT. Alpha is a firm 0.0: not transparency (the sky does not negotiate), but
    // flat.frag's glow mark for the bloom pass -- and the sky, stars included, does not glow
    // around itself. Color finalized, packaged, delivered.
    frag_color = vec4(color, 0.0);
}
