// text.frag: colors a glyph pixel. No "#version": the game adds it.

in vec2 v_uv;
in vec4 v_color;

// The glyph atlas. It has a single channel (red): how much of each pixel the letter
// covers, from 0 (empty) to 1 (fully inside the letter).
uniform sampler2D u_atlas;

out vec4 frag_color;

void main() {
    float coverage = texture(u_atlas, v_uv).r;
    // The coverage becomes transparency; blending (set in text_renderer.cpp) mixes the
    // text color with what's behind it.
    frag_color = vec4(v_color.rgb, v_color.a * coverage);
}
