// flat.frag: THE EVERYMAN OF THE RENDERER, AND IT HAS SEEN THINGS. Every low-poly
// car, person, building and curb walks through here to be lit, tinted, fogged,
// grassed and moonlit -- all before breakfast, per pixel, millions of times
// per frame. Runs once per pixel covered by a triangle. No "#version" line: the game
// adds it.

in vec3 v_color;
in vec3 v_normal;
in vec3 v_world_position;
in float v_emissive;
in vec3 v_tint;                  // multiplies the color (cars of many colors, one mesh)

uniform vec3 u_camera_position;
uniform vec3 u_fog_color;        // the sky color, so far things melt into the sky
uniform vec2 u_fog_range;        // x = distance where fog starts, y = where it's total

// Lights (see render/lighting.hpp).
uniform vec3 u_sun_direction;    // points TO the sun
uniform vec3 u_sun_color;
uniform vec3 u_moon_direction;
uniform vec3 u_moon_color;
uniform vec3 u_ambient_sky;
uniform vec3 u_ambient_ground;
uniform float u_window_glow;     // 0 by day, 1 at night
// The lamps that are on whatever the hour: an interior's ceiling lamps (emissive 2, their
// own color). Outdoors it follows the night (the same as u_window_glow); indoors it is 1,
// while the rest of an interior's emissive (screens, panes of daylight) stays as it was.
uniform float u_lamps_on;

uniform float u_ground;          // 1 = the city's open ground (concrete downtown, grass elsewhere), 0 = plain
uniform vec4 u_downtown;         // downtown's rectangle on the ground: min x, min z, max x, max z
uniform float u_time;            // seconds, wrapped every hour: the wind (as in flat.vert)

// THE SUPPORT GROUP FOR ABANDONED PEDESTRIANS, formerly known as "the nearby lights"
// (Game::gather_mover_lights): street lamps, lit windows and shop fronts, headlights.
// Backstory: the city's ground only ever got a PAINTED pool of light from these
// (night_pool.frag, light_pool.frag), so a person or a car standing in that pool
// stayed as dark as the night around it -- standing inside a street lamp's glow,
// casting zero shadow of doubt that the lighting was lying. For people and vehicles
// the game switches these on (u_light_count > 0) and each light is computed for real,
// at a point, like physics intended; for buildings and ground it stays 0 and the loop
// never runs. Justice, one uniform at a time.
const int max_lights = 32;  // Game::max_mover_lights
uniform int u_light_count;
uniform vec4 u_light_at[max_lights];     // xyz: where the light is; w: how far it reaches (m)
uniform vec4 u_light_color[max_lights];  // rgb: its color times its strength; w: a beam's cone (cosine), 0 = all around
uniform vec4 u_light_aim[max_lights];    // xyz: a beam's direction (headlights, a window's light pouring out)
// How strong the nearby lights are now: the night outdoors (u_window_glow), 1 indoors.
uniform float u_light_gain;
// 1 for what moves (every face lit); 0 for the buildings, the platforms and the rooms
// (2026-11-10, the lights' round 2): their walls, columns, seats and ceilings take the
// nearby lights too, but not their floors, which already wear the painted pools of the
// same lights (night_pool.frag, indoor_pool.frag): lit twice they would turn white.
uniform float u_light_floors;

// THE SUN'S SHADOWS (render/shadow_map.hpp). The city was drawn once more from the sun,
// keeping only how far from it each pixel's first obstacle is, in three pictures (the
// cascades): a sharp one for the first 30 m, a middle one, a coarse one to the end of the
// shadows. Here every pixel asks the sharpest picture that covers it: "is something
// between me and the sun?" Only the sun's (or the moon's) own light is taken away; the
// sky's ambient light and the city's lamps stay.
uniform highp sampler2DArrayShadow u_shadow_map;
uniform mat4 u_shadow_matrix[3];  // world -> the picture's 0..1 (x, y) and depth (z)
uniform vec3 u_shadow_texel;      // a picture's pixel, in meters, per cascade
uniform vec3 u_shadow_bias;       // one pixel's size in the picture's depth, per cascade
uniform float u_shadow_strength;  // 0 = no shadows (indoors, a map, the sun down); 1 = the sun fully stopped
uniform vec2 u_shadow_fade;       // meters from the eye: the shadows fade out from x to y
uniform int u_shadow_cascades;    // how many of the pictures the quality level uses (2 or 3)
uniform int u_shadow_taps;        // reads per pixel at an edge: 4 (a 2 x 2 square) or 9 (3 x 3)

// 1 = in the sun, 0 = in shadow, soft in between.
float sun_shadow(vec3 n, vec3 light) {
    if (u_shadow_strength <= 0.0) return 1.0;
    float far = distance(v_world_position, u_camera_position);
    if (far >= u_shadow_fade.y) return 1.0;
    // A FACE TURNED AWAY gets no sun anyway (Lambert): nothing to ask.
    float facing = dot(n, light);
    if (facing <= 0.0) return 1.0;
    vec2 pixel = 1.0 / vec2(textureSize(u_shadow_map, 0).xy);
    for (int c = 0; c < 3; ++c) {
        if (c >= u_shadow_cascades) break;
        // THE STEP ALONG THE NORMAL ("normal offset"): ask from a point a pixel and a half
        // off the surface, more the more the face leans away from the sun. A face can't
        // shadow itself then (the stripes called "shadow acne"), and a contact keeps its
        // shadow: the step is a few centimeters in the sharp picture.
        float lean = 1.0 - facing;
        vec3 at = v_world_position + n * u_shadow_texel[c] * (1.0 + 2.0 * lean);
        vec4 p = u_shadow_matrix[c] * vec4(at, 1.0);
        // Inside this picture, with a margin for the nine reads below? Else the next one.
        vec2 margin = pixel * 3.0;
        if (any(lessThan(p.xy, margin)) || any(greaterThan(p.xy, 1.0 - margin)) || p.z > 1.0) continue;
        float reference = p.z - u_shadow_bias[c];
        // PERCENTAGE-CLOSER FILTERING: reads in a square around the point, each already a
        // blend of four pixels (the texture's comparison filter): the answers' average is
        // a soft edge instead of a staircase. Nine reads a pixel apart (Medium, High): an
        // edge some three pixels wide. Four reads half a pixel off the point (Low): about
        // two pixels wide, for less than half the work.
        float lit = 0.0;
        if (u_shadow_taps >= 9) {
            for (int y = -1; y <= 1; ++y) {
                for (int x = -1; x <= 1; ++x) {
                    lit += texture(u_shadow_map, vec4(p.xy + vec2(float(x), float(y)) * pixel, float(c), reference));
                }
            }
            lit /= 9.0;
        } else {
            for (int y = 0; y < 2; ++y) {
                for (int x = 0; x < 2; ++x) {
                    lit += texture(u_shadow_map, vec4(p.xy + (vec2(float(x), float(y)) - 0.5) * pixel, float(c), reference));
                }
            }
            lit /= 4.0;
        }
        // Far off the shadows fade away before the fog (the view distance's steps move
        // both): a hard end line would show.
        float fade = 1.0 - smoothstep(u_shadow_fade.x, u_shadow_fade.y, far);
        return mix(1.0, lit, u_shadow_strength * fade);
    }
    return 1.0;
}

// The alpha is not a transparency here: it marks how much this pixel GLOWS (the lit
// windows, lamps and signs), for the bloom pass that gives each of them a halo of light
// around it (render/bloom.cpp). 0 for everything that only reflects light.
out vec4 frag_color;

// THE GROUND, REDRESSED (BACKLOG, "The housing look": no more green checkerboard). The
// old 1 m checkerboard is gone. Downtown the open ground is gray concrete in slabs;
// everywhere else it is grass whose color wanders (cheap noise, three sizes), with dry
// patches, and the wind rolling over it in lighter waves, the way a field shows the
// pale side of its blades when a gust bends them. Tufts of real grass stand on it near
// the player (grass.vert).

// A hash of a 2D cell: a repeatable "random" number from 0 to 1 for each integer pair.
float hash21(vec2 cell) {
    vec3 p = fract(vec3(cell.xyx) * 0.1031);
    p += dot(p, p.yzx + 33.33);
    return fract((p.x + p.y) * p.z);
}
// VALUE NOISE: a random number at each corner of a 1 x 1 grid, blended smoothly in
// between. Smooth hills of 0..1, as big as the grid, no seams.
float value_noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    float a = hash21(i), b = hash21(i + vec2(1.0, 0.0)), c = hash21(i + vec2(0.0, 1.0)), d = hash21(i + vec2(1.0, 1.0));
    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}
// The wind's long wave of gusts, as in flat.vert and grass.vert.
const vec2 wind_direction = vec2(0.8, -0.6);
float wind_gust(vec2 p, float t) {
    return 0.5 + 0.5 * sin(dot(p, wind_direction) * 0.063 - t * 1.25);
}

vec3 concrete_ground(vec2 p) {
    // Slabs 2.5 m square, each a shade of its own, joints between them. The joints fade
    // away where a pixel covers more than a few centimeters (far off), or they would
    // shimmer (fwidth: how many meters one pixel spans here).
    const float slab = 2.5;
    float fw = max(fwidth(p.x), fwidth(p.y));
    vec2 cell = floor(p / slab);
    vec3 color = vec3(0.60, 0.60, 0.58) * (0.95 + 0.08 * hash21(cell));
    color *= 0.94 + 0.06 * value_noise(p / 11.0);  // old stains, larger than a slab
    vec2 to_joint = abs(fract(p / slab) - 0.5) * slab;  // 0 in the slab's middle, slab/2 at a joint
    float joint = smoothstep(slab * 0.5 - 0.04 - fw, slab * 0.5 - 0.04, max(to_joint.x, to_joint.y));
    joint *= 1.0 - smoothstep(0.04, 0.3, fw);
    return color * (1.0 - 0.22 * joint);
}

vec3 grass_ground(vec2 p) {
    float fw = max(fwidth(p.x), fwidth(p.y));
    float broad = value_noise(p / 23.0);
    float mid = value_noise(p / 6.5);
    // The small blotches fade toward their average where pixels grow bigger than them.
    float fine = mix(value_noise(p / 1.7), 0.5, smoothstep(0.2, 1.0, fw));
    vec3 color = mix(vec3(0.25, 0.45, 0.19), vec3(0.36, 0.56, 0.24), mid);
    color = mix(color, vec3(0.50, 0.50, 0.27), smoothstep(0.62, 0.88, broad) * 0.55);  // dry patches
    color *= 0.92 + 0.16 * fine;
    // The gusts: a long wave along the wind (the same as the trees'), broken into
    // streaks by a noise that travels with the wind at 4 m/s.
    float streak = value_noise((p - wind_direction * u_time * 4.0) / 9.0);
    color *= 0.95 + 0.10 * wind_gust(p, u_time) * streak;
    return color;
}

void main() {
    // NORMALIZE FIRST, ASK QUESTIONS LATER: interpolated normals are never quite
    // unit-length, so n gets squared away before any light dares dot with it. Then
    // base color meets its tint -- one mesh, a thousand paint jobs, the dream of every
    // fleet manager.
    vec3 n = normalize(v_normal);
    vec3 base = v_color * v_tint;
    // THE GROUND WEARS ITS COSTUME: when u_ground says so, the one big square under the
    // city becomes concrete inside downtown's rectangle and grass outside it -- zoning
    // achieved entirely in the fragment shader.
    if (u_ground > 0.5) {
        vec2 p = v_world_position.xz;
        bool downtown = all(greaterThanEqual(p, u_downtown.xy)) && all(lessThanEqual(p, u_downtown.zw));
        base = downtown ? concrete_ground(p) : grass_ground(p);
    }

    // LAMBERT'S LAW, THE OLDEST TRICK IN THE LIGHT BOOK: a surface receives light in
    // proportion to the cosine of the angle between its normal and the light, which
    // for unit vectors is exactly dot(n, light). Facing the light: 1. Edge-on: 0.
    // Facing away: negative -- nature's way of saying "no", so we clamp to 0. The sun
    // and the moon both pay their dues this way, working opposite shifts.
    float sun = max(dot(n, u_sun_direction), 0.0);
    float moon = max(dot(n, u_moon_direction), 0.0);
    // AMBIENT SPLIT DOWN THE MIDDLE: faces looking up collect skylight, faces looking
    // down collect bounce from the ground -- n.y remapped to 0..1 does the choosing.
    // Night is never truly black; it just has fewer witnesses.
    vec3 ambient = mix(u_ambient_ground, u_ambient_sky, n.y * 0.5 + 0.5);
    // THE SHADOW TAKES ONLY THE DIRECT LIGHT: the sun's by day, the moon's at night (only
    // one is ever above the horizon, and the shadows come from that one: u_shadow_strength
    // is 0 while neither is high enough).
    float shade = sun_shadow(n, u_sun_direction.y > 0.0 ? u_sun_direction : u_moon_direction);
    vec3 lit = base * (ambient + (u_sun_color * sun + u_moon_color * moon) * shade);

    // THE PERSONAL LIGHT ENTOURAGE, ASSEMBLED PER PIXEL: for each nearby light, three
    // favors -- how far you are from it (fading smoothly to nothing at its reach,
    // like the painted pools' rims), how much this face turns toward it ("wrapped"
    // Lambert, +0.4/1.4: a face edge-on still gets a sliver, as light bouncing off
    // the sidewalk would), and, for a beam, whether we're inside its cone. Headlights,
    // lamps, spilling windows: the night shift pays its electric bill honestly.
    vec3 near_light = vec3(0.0);
    for (int i = 0; i < u_light_count; ++i) {
        vec3 to_light = u_light_at[i].xyz - v_world_position;
        float d = length(to_light);
        if (d > u_light_at[i].w) continue;  // out of its reach: nothing to add (most of them, on a wall)
        vec3 l = to_light / max(d, 0.001);
        float reach = 1.0 - smoothstep(0.0, u_light_at[i].w, d);
        float facing = clamp((dot(n, l) + 0.4) / 1.4, 0.0, 1.0);
        float cone = 1.0;
        float edge = u_light_color[i].w;
        if (edge > 0.0) cone = smoothstep(edge, mix(edge, 1.0, 0.4), dot(-l, u_light_aim[i].xyz));
        near_light += u_light_color[i].rgb * (reach * facing * cone);
    }
    // A floor of the buildings (u_light_floors 0) keeps only its painted pools: faces
    // turned up fade out of these lights from 57 to 26 degrees off the vertical.
    // Their other faces take 70% of what a body would: walls and columns are broad and
    // mostly pale, and at full strength a station's lamps washed them into one gray haze.
    float floor_cut = mix((1.0 - smoothstep(0.55, 0.9, n.y)) * 0.7, 1.0, u_light_floors);
    lit += base * near_light * u_light_gain * floor_cut;

    // SIGNAGE LAW: WHAT GLOWS, AND IN WHOSE NAME. Lit windows and lamps blend toward
    // a warm light color at night -- but emissive values of 2 mean "a sign that glows
    // in its OWN color" (the hospital's red cross, the parking garage's blue "P", the
    // strobes on emergency vehicles). Values between 1.5 and 2 glow in their own
    // color only PART way -- 1.5 means none, 2 means fully -- a shop's painted front
    // gradually washed by its own lights (world/city_lots.cpp, 1.62). Twenty years of
    // branding law, encoded in one clamp.
    // The lamps (emissive 2 and up) are on whenever u_lamps_on says so: indoors always.
    bool own_color = v_emissive > 1.5;
    vec3 glow = own_color ? min(base * 1.5 + 0.1, vec3(1.0)) : vec3(1.0, 0.85, 0.55);
    float amount = own_color ? clamp((v_emissive - 1.5) * 2.0, 0.0, 1.0) : min(v_emissive, 1.0);
    float switched_on = v_emissive >= 1.95 ? max(u_window_glow, u_lamps_on) : u_window_glow;
    float emit = clamp(amount * switched_on, 0.0, 1.0);
    lit = mix(lit, glow, emit);

    // AND AT LAST, THE VEIL: distance fog, 0 near the camera, rising smoothly to 1
    // at u_fog_range.y, everything quietly dissolving into the exact color of the
    // sky. No pop-in, no hazy seam, just geometry politely withdrawing from the
    // stage before anyone notices it was ever there.
    float distance_to_eye = distance(v_world_position, u_camera_position);
    float fog = smoothstep(u_fog_range.x, u_fog_range.y, distance_to_eye);
    // The glow mark for the bloom (see frag_color above), fading with the fog like the color.
    frag_color = vec4(mix(lit, u_fog_color, fog), emit * (1.0 - fog));
}
