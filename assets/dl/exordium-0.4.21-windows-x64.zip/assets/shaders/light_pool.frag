// light_pool.frag: a pool of headlight on the road, faked.
//
// Real lighting would compute, for every pixel of the road, how much light each nearby
// headlight sends to it: costly with a hundred cars. Instead each car carries a flat
// shape lying on the asphalt in front of it, and this shader paints a soft glow on it:
// brightest a few meters ahead, fading toward the far end and toward the sides. The game
// draws it with ADDITIVE blending (the result is added to the color already on screen),
// so it brightens whatever road is underneath, the way light does, and dark asphalt
// gets the warm pool without any light calculation at all.

in vec2 v_pool;
in vec3 v_world_position;

uniform float u_strength;        // 0 by day, 1 at night (the lighting's window glow)
uniform float u_gain;            // 1 for one pool; 0.65 for each of two beams that overlap
uniform vec3 u_camera_position;
uniform vec2 u_fog_range;

out vec4 frag_color;

void main() {
    float across = v_pool.x;
    float along = v_pool.y;
    // Rises quickly just past the bumper, then fades with the square of the distance
    // left (light spreads out, so it weakens fast).
    float lengthwise = smoothstep(0.0, 0.12, along) * (1.0 - along) * (1.0 - along);
    // Soft sides: full in the middle, nothing at the edges.
    float sideways = 1.0 - smoothstep(0.35, 1.0, abs(across));
    float light = lengthwise * sideways * 0.42 * u_gain * u_strength;
    // Far away the fog swallows it, like everything else.
    float fog = smoothstep(u_fog_range.x, u_fog_range.y, distance(v_world_position, u_camera_position));
    frag_color = vec4(vec3(1.0, 0.86, 0.62) * light * (1.0 - fog), 0.0);  // alpha 0: no glow mark (flat.frag)
}
