// bloom.vert: one triangle that covers the whole screen, for the bloom's passes
// (render/bloom.cpp). No vertex buffer at all: the three corners are made from the
// vertex's number (0, 1, 2) as (-1,-1), (3,-1), (-1,3). The triangle is bigger than the
// screen, and the GPU cuts what falls outside: every pixel is covered exactly once, with
// no seam down a diagonal as two triangles would have.

out vec2 v_uv;  // 0..1 across the screen (past 1 outside it, cut away)

void main() {
    vec2 corner = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));  // (0,0), (2,0), (0,2)
    v_uv = corner;
    gl_Position = vec4(corner * 2.0 - 1.0, 0.0, 1.0);
}
