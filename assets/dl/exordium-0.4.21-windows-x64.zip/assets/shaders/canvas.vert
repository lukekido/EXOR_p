// canvas.vert: THE MINIMALIST'S MANIFESTO. Flat 2D shapes -- the map, the minimap, the
// markers -- pushed through exactly two matrices and out the other side, wearing their
// colors. No lighting because the map is above such worldly concerns. No fog because
// the minimap refuses to acknowledge distance. No "#version": the game adds it.

layout(location = 0) in vec2 a_position;  // in the shape's own units (map: meters)
layout(location = 1) in vec4 a_color;

uniform mat4 u_transform;   // the shape's units -> pixels (pan and zoom live here)
uniform mat4 u_projection;  // orthographic: pixels -> screen

out vec4 v_color;

void main() {
    // HAND THE COLOR THROUGH, UNTOUCHED: a color is a promise, and nobody downstream
    // has any business editing it.
    v_color = a_color;
    // TWO MATRIX MULTIPLIES, END TO END: local units (meters, if you're the map) get
    // translated, scaled and panned into pixel space by u_transform, then pinned to
    // the screen by an orthographic u_projection -- the flattest camera in existence,
    // and proud of it.
    gl_Position = u_projection * u_transform * vec4(a_position, 0.0, 1.0);
}
