// indoor_pool.vert: the pools of light under the lamps of an interior (see
// indoor_pool.frag). The pools are baked into one mesh per interior when it is built
// (world::Interiors::bake_pools), so the vertices carry everything, in the usual slots:
// the COLOR slot holds the corner's (x, z) on the pool's disc (-1..+1 from the lamp, in
// radii), the NORMAL slot the light's color (a pool always faces up, so the normal isn't
// needed), and the EMISSIVE slot its strength.

layout(location = 0) in vec3 a_position;
layout(location = 1) in vec3 a_normal;
layout(location = 2) in vec3 a_color;
layout(location = 3) in float a_emissive;

uniform mat4 u_view_projection;

out vec2 v_pool;
out vec3 v_light;
out float v_strength;

void main() {
    v_pool = a_color.xy;
    v_light = a_normal;
    v_strength = a_emissive;
    gl_Position = u_view_projection * vec4(a_position, 1.0);
}
