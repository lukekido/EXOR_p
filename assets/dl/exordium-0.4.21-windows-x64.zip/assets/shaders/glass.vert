// glass.vert: the inside of the buses' and the monorail cars' windows (see glass.frag).
// Same vertex layout as every mesh (render/mesh.cpp); this shader reads the COLOR slot
// as the corner's place on its pane, in meters (x across, y up, z the pane's width) and
// the EMISSIVE slot as the pane's height.

layout(location = 0) in vec3 a_position;
layout(location = 1) in vec3 a_normal;
layout(location = 2) in vec3 a_color;
layout(location = 3) in float a_emissive;

uniform mat4 u_model;
uniform mat4 u_view_projection;

out vec3 v_world_position;
out vec3 v_normal;
out vec2 v_pane;   // where on the pane, in meters from its lower corner
out vec2 v_size;   // the pane's width and height, in meters

void main() {
    vec4 world = u_model * vec4(a_position, 1.0);
    v_world_position = world.xyz;
    // The vehicles' transforms only turn and move (no stretching), so the normal turns
    // with the same matrix.
    v_normal = mat3(u_model) * a_normal;
    v_pane = a_color.xy;
    v_size = vec2(a_color.z, a_emissive);
    gl_Position = u_view_projection * world;
}
