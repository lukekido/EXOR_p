// text.vert: places glyph rectangles on screen. No "#version": the game adds it.

layout(location = 0) in vec2 a_position;  // pixels, from the top-left corner
layout(location = 1) in vec2 a_uv;        // where the glyph is in the atlas
layout(location = 2) in vec4 a_color;

uniform mat4 u_projection;  // orthographic: pixels -> screen

out vec2 v_uv;
out vec4 v_color;

void main() {
    v_uv = a_uv;
    v_color = a_color;
    gl_Position = u_projection * vec4(a_position, 0.0, 1.0);
}
