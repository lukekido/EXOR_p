// night_pool.vert: the city's light pools at night (see night_pool.frag), INSTANCED.
//
// Every pool is the same unit square, x and z from -1 to +1, lying flat. Each copy
// carries its own matrix (a_model) that scales, turns and moves the square onto the
// ground under a street lamp, in front of a lit shop window, or wherever the light falls.
// A few thousand pools cost ONE draw call this way (see flat_instanced.vert).
// The COLOR slot of the vertices carries the corner's (x, z) on the square instead of a
// color, like light_pool.vert does for the headlights.

layout(location = 0) in vec3 a_position;
layout(location = 1) in vec3 a_normal;
layout(location = 2) in vec3 a_color;
layout(location = 3) in float a_emissive;
// Per instance: where the pool is, the light's color, and its strength. A NEGATIVE
// strength means "a spill": light pouring out of a window or a shop front, brightest at
// the wall (the square's x = -1 edge) and fading outward. Positive: a round pool.
layout(location = 4) in mat4 a_model;
layout(location = 8) in vec3 a_tint;
layout(location = 9) in float a_glow;

uniform mat4 u_view_projection;

out vec2 v_pool;            // the corner's (x, z) on the unit square, blended by the GPU
out vec3 v_light;           // the light's color
out float v_strength;       // its strength, negative for a spill
out vec3 v_world_position;

void main() {
    vec4 world = a_model * vec4(a_position, 1.0);
    v_world_position = world.xyz;
    v_pool = a_color.xy;
    v_light = a_tint;
    v_strength = a_glow;
    gl_Position = u_view_projection * world;
    // Cut at a plane while the city is drawn for a window indoors (the vertex header,
    // render/shader.cpp); nothing at any other time.
    CLIP_WORLD(world.xyz);
}
