// bloom_add.frag: the halos laid over the frame (render/bloom.cpp). Two sizes of the
// same blurred light: a tight one (a quarter of the screen's size) that makes a lamp
// read as bright, and a wide, faint one (an eighth) that is the haze a lit facade or a
// sign throws on the night around it. The game ADDS this to the screen.

in vec2 v_uv;

uniform sampler2D u_near;   // the quarter-size blur
uniform sampler2D u_wide;   // the eighth-size blur
uniform float u_strength;   // 0 by day, the night's amount after dusk; 1 indoors

out vec4 frag_color;

void main() {
    vec3 halo = texture(u_near, v_uv).rgb * 0.9 + texture(u_wide, v_uv).rgb * 0.7;
    frag_color = vec4(halo * u_strength, 0.0);
}
