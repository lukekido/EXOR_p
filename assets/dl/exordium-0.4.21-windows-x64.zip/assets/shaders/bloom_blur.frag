// bloom_blur.frag: a soft blur in one direction (render/bloom.cpp runs it across, then
// down). A Gaussian of nine texels folded into five bilinear taps: between two texels the
// GPU blends them for free, so one tap placed at the right point between them reads both
// with the right weights (offsets 1.38 and 3.23 texels).

in vec2 v_uv;

uniform sampler2D u_source;
uniform vec2 u_step;  // one texel along the blur's direction, in 0..1 units

out vec4 frag_color;

void main() {
    vec3 sum = texture(u_source, v_uv).rgb * 0.2270;
    sum += (texture(u_source, v_uv + u_step * 1.3846).rgb + texture(u_source, v_uv - u_step * 1.3846).rgb) * 0.3162;
    sum += (texture(u_source, v_uv + u_step * 3.2308).rgb + texture(u_source, v_uv - u_step * 3.2308).rgb) * 0.0703;
    frag_color = vec4(sum, 1.0);
}
