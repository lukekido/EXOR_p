// light_pool.vert: the fake headlight pools (see light_pool.frag).
// Same vertex layout as every mesh (render/mesh.cpp); this shader reads the COLOR slot
// as two coordinates on the pool instead of a color: x = across (-1 left edge .. +1
// right edge), y = along (0 at the bumper .. 1 at the far end).

layout(location = 0) in vec3 a_position;
layout(location = 1) in vec3 a_normal;
layout(location = 2) in vec3 a_color;
layout(location = 3) in float a_emissive;

uniform mat4 u_model;
uniform mat4 u_view_projection;

out vec2 v_pool;            // (across, along), blended across the quad by the GPU
out vec3 v_world_position;

void main() {
    vec4 world = u_model * vec4(a_position, 1.0);
    v_world_position = world.xyz;
    v_pool = a_color.xy;
    gl_Position = u_view_projection * world;
    // Cut at a plane while the city is drawn for a window indoors (the vertex header,
    // render/shader.cpp); nothing at any other time.
    CLIP_WORLD(world.xyz);
}
