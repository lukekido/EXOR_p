// flat.vert: THE UNSUNG BUREAUCRAT OF THE LOW-POLY WORLD. Every car, citizen, building
// and curb files its paperwork here -- one form per vertex, millions of forms per
// frame, stamped and forwarded without complaint. It reads flat-colored geometry from
// the VBO, pins it into the world, and hands it up the pipeline. Runs once per
// vertex. No "#version" line: the game adds the right one per platform.

// Inputs per vertex, read from the VBO as the VAO recipe describes (render/mesh.cpp).
layout(location = 0) in vec3 a_position;
layout(location = 1) in vec3 a_normal;
layout(location = 2) in vec3 a_color;
layout(location = 3) in float a_emissive;

// Same value for every vertex in one draw call.
uniform mat4 u_model;            // places this object in the world
uniform mat4 u_view_projection;  // camera: world -> screen
uniform vec3 u_tint;             // multiplies the color (cars of many colors, one mesh)
uniform float u_time;            // seconds, wrapped every hour: what moves the wind
uniform vec3 u_camera_position;  // where the camera is (flat.frag's too): how far a face is

// THE FACE'S PAPERWORK (game/person_rig.cpp): set before each person's head is drawn.
// x: the person's own number (0..1), what puts their blinks and words out of step with
//    everybody else's; y: 1 = eyes open (blinking now and then), 0 = shut;
// z: the mouth, 0 = shut, 1 = talking, 2 = screaming; w: a clock in seconds.
uniform vec4 u_face;
uniform vec3 u_eye_color;        // the iris, by person

// THE ARTIFICIAL WIND (the same in grass.vert and flat.frag's ground): one breeze from
// the south-west. A long wave of gusts rolls across the city along the wind (about
// 100 m from crest to crest, one every 5 s), and a quicker flutter, different at every
// spot, rides on it. Returns how far a thing that sways fully is pushed, in meters.
const vec2 wind_direction = vec2(0.8, -0.6);
float wind_gust(vec2 p, float t) {
    return 0.5 + 0.5 * sin(dot(p, wind_direction) * 0.063 - t * 1.25);
}
vec2 wind_offset(vec2 p, float t) {
    float gust = wind_gust(p, t);
    float flutter = sin(t * 2.1 + p.x * 0.35 + p.y * 0.27) * 0.6 + sin(t * 3.4 + p.y * 0.5 - p.x * 0.2) * 0.4;
    return wind_direction * (0.32 * gust + 0.14 * flutter * (0.4 + gust));
}

// THE FACE: TWO EYES AND A MOUTH ON THE FRONT OF EVERY JOINTED HEAD. They are a few
// flat quads inside the head's own mesh (no extra draw per person: there are thousands
// of people), each marked by an emissive of -10 (the white of an eye), -11 (the iris)
// or -12 (the mouth). Nothing glows or sways that far below zero, so the number was
// free. This vertex shader is what makes them alive, from the u_face numbers:
//   - a BLINK: every few seconds (2.8 to 6.2 s, the person's own rhythm) the eye
//     squashes to a thin dark line around its middle for about a fifth of a second;
//   - the MOUTH: a thin line, stretched taller in syllables while talking (with breaths
//     between phrases), wide open while screaming;
//   - the FADE: from 22 m the face melts into the skin, and past 30 m it is folded away
//     to nothing (a few pixels of eyes would only flicker; the head stays a head).
const float face_eye_y = 1.60;      // the eyes' middle, in the head mesh's frame (m)
const float face_mouth_y = 1.50;    // the mouth's middle
const float face_fade_from = 22.0;  // m from the camera
const float face_gone_at = 30.0;
const vec3 face_lashes = vec3(0.16, 0.11, 0.09);  // a shut eye: a dark line

void face(inout vec3 position, inout vec3 color, inout vec3 tint) {
    float part = floor(-a_emissive - 9.5);  // 0 white, 1 iris, 2 mouth
    float far = length(u_model[3].xyz - u_camera_position);
    if (far > face_gone_at) {
        position = vec3(0.0, face_eye_y, 0.0);  // all corners on one point: no pixels
        return;
    }
    float t = u_face.w;
    float own = u_face.x;
    if (part < 1.5) {
        // The blink: a period of its own; closed around 0.1 s into it, fully open again
        // 0.07 s either side (squeezed shut in 0.05 s, as eyelids are quick).
        float period = 2.8 + 3.4 * fract(own * 13.7);
        float phase = mod(t + own * 97.0, period);
        float shut = 1.0 - smoothstep(0.04, 0.11, abs(phase - 0.1));
        shut = max(shut, 1.0 - u_face.y);
        position.y = face_eye_y + (position.y - face_eye_y) * mix(1.0, 0.18, shut);
        if (part > 0.5) {
            color = vec3(1.0);
            tint = u_eye_color;
        } else {
            tint = vec3(1.0);
        }
        color = mix(color * tint, face_lashes, shut);
        tint = vec3(1.0);
    } else {
        // The mouth. Talking: syllables (|sin|, about 3 a second) inside phrases that
        // stop for a breath now and then. Screaming: open wide, trembling a little.
        float open = 0.0;
        float wide = 1.0;
        if (u_face.z > 1.5) {
            open = 0.85 + 0.15 * sin(t * 23.0);
            wide = 1.3;
        } else if (u_face.z > 0.5) {
            float syllables = abs(sin(t * 9.0 + own * 40.0));
            float phrase = smoothstep(-0.7, -0.3, sin(t * 1.9 + own * 17.0));
            open = syllables * phrase * 0.7;
        }
        position.y = face_mouth_y + (position.y - face_mouth_y) * (1.0 + 5.0 * open);
        position.z *= wide;
        tint = vec3(1.0);
    }
    // Melting into the skin from 22 m: the head's own tint (u_tint) on a white color.
    float fade = smoothstep(face_fade_from, face_gone_at, far);
    color = mix(color, vec3(1.0), fade);
    tint = mix(tint, u_tint, fade);
}

// PASSED ON, UNEDITED, TO THE FRAGMENT SHADER: color, normal, world position,
// emissive, tint -- five suitcase halves per corner, blended by the GPU between
// each triangle's three vertices on the way down to pixels.
out vec3 v_color;
out vec3 v_normal;
out vec3 v_world_position;
out float v_emissive;
out vec3 v_tint;

void main() {
    // STAMP THE PASSPORT: one multiply by u_model and this vertex officially resides
    // somewhere in the world -- its world position gets recorded for the fragment
    // shader's lighting and fog homework later.
    vec3 position = a_position;
    vec3 color = a_color;
    vec3 tint = u_tint;
    // -10 AND BELOW: A PIECE OF A FACE (see face() above), never glowing, never swaying.
    bool is_face = a_emissive < -9.5;
    if (is_face) face(position, color, tint);
    vec4 world = u_model * vec4(position, 1.0);
    // A NEGATIVE EMISSIVE MEANS "I SWAY": the trees' crowns and palm leaves carry how
    // much the wind moves them there (world/city_housing.cpp, add_leaf_lump: little
    // where the crown meets the trunk, most at its top). Nothing glows negatively, so
    // the number was free; the fragment shader gets 0 (not glowing).
    if (a_emissive < 0.0 && !is_face) {
        world.xz += wind_offset(world.xz, u_time) * -a_emissive;
    }
    v_world_position = world.xyz;
    // ROTATION COURTESY CALL: normals turn with the object. mat3() strips u_model down
    // to just its rotational core -- our objects are moved and turned, never stretched,
    // so no inverse-transpose ceremony is required. (Objects that stretch would need
    // the full pomp; these behave, and are thanked for it.)
    v_normal = mat3(u_model) * a_normal;
    v_color = color;
    v_emissive = max(a_emissive, 0.0);
    v_tint = tint;

    // THE ACTUAL JOB: gl_Position, where this vertex lands in "clip space" -- the
    // shader's sole legally required output. The GPU then divides x, y, z by w; the
    // perspective projection makes w grow with distance, so far things shrink. All
    // of depth perception, in one implicit division.
    gl_Position = u_view_projection * world;
    // Cut at a plane while the city is drawn for a window indoors (the vertex header,
    // render/shader.cpp); nothing at any other time.
    CLIP_WORLD(world.xyz);
}
