// grass.vert: THE GARDENER WHO NEVER LEAVES THE PLAYER'S SIDE. One tuft of three blades
// is drawn about 12,000 times in a single call (render/grass.cpp); this shader decides,
// for each copy, where it stands, how big it is, whether it may grow there at all, and
// how far the wind bends it. Pairs with flat.frag, so a tuft is lit and fogged exactly
// like the ground it stands on. No "#version" line: the game adds it.

layout(location = 0) in vec3 a_position;
layout(location = 1) in vec3 a_normal;
layout(location = 2) in vec3 a_color;
layout(location = 3) in float a_emissive;  // here: how high up the blade (0 foot, 1 tip)

uniform mat4 u_view_projection;
uniform vec3 u_camera_position;
uniform float u_time;            // seconds, wrapped every hour: the wind
uniform vec4 u_downtown;         // downtown's rectangle (concrete there: no grass)
uniform sampler2D u_mask;        // 1 = covered (road, yard, building, water), 0 = open ground
uniform vec4 u_mask_area;        // where the mask lies: min x, min z, width, depth (1 m per texel)
uniform int u_grid;              // tufts per side of the grid around the camera
uniform float u_spacing;         // meters between them

out vec3 v_color;
out vec3 v_normal;
out vec3 v_world_position;
out float v_emissive;
out vec3 v_tint;

// The same hash, noise and wind as flat.frag's ground and flat.vert's trees, so the
// tufts ripple with the grass under them and the crowns above them.
float hash21(vec2 cell) {
    vec3 p = fract(vec3(cell.xyx) * 0.1031);
    p += dot(p, p.yzx + 33.33);
    return fract((p.x + p.y) * p.z);
}
float value_noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    float a = hash21(i), b = hash21(i + vec2(1.0, 0.0)), c = hash21(i + vec2(0.0, 1.0)), d = hash21(i + vec2(1.0, 1.0));
    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}
const vec2 wind_direction = vec2(0.8, -0.6);
float wind_gust(vec2 p, float t) {
    return 0.5 + 0.5 * sin(dot(p, wind_direction) * 0.063 - t * 1.25);
}
vec2 wind_offset(vec2 p, float t) {
    float gust = wind_gust(p, t);
    float flutter = sin(t * 2.1 + p.x * 0.35 + p.y * 0.27) * 0.6 + sin(t * 3.4 + p.y * 0.5 - p.x * 0.2) * 0.4;
    return wind_direction * (0.32 * gust + 0.14 * flutter * (0.4 + gust));
}

void main() {
    // WHICH CELL AM I? The grid is centered on the camera's cell and slides with it a
    // whole cell at a time, so every tuft belongs to a fixed cell of the world: walking
    // on, the far row drops off and a new one appears, but no tuft ever moves.
    int half_grid = u_grid / 2;
    ivec2 g = ivec2(gl_InstanceID % u_grid, gl_InstanceID / u_grid) - ivec2(half_grid);
    vec2 cell = floor(u_camera_position.xz / u_spacing) + vec2(g);
    float h1 = hash21(cell), h2 = hash21(cell + 17.31), h3 = hash21(cell + 41.77);
    vec2 foot = (cell + vec2(h1, h2)) * u_spacing;  // somewhere inside its cell, never on a grid line

    // MAY IT GROW HERE? Not on anything the city built (the mask), not downtown (concrete),
    // not off the map. And "low, random grass": noise makes patches, thick in some places
    // and bare in others, and each tuft its own height (0.15-0.4 m).
    vec2 uv = (foot - u_mask_area.xy) / u_mask_area.zw;
    bool inside = all(greaterThanEqual(uv, vec2(0.0))) && all(lessThanEqual(uv, vec2(1.0)));
    float covered = inside ? texture(u_mask, uv).r : 1.0;
    bool downtown = all(greaterThanEqual(foot, u_downtown.xy)) && all(lessThanEqual(foot, u_downtown.zw));
    float patches = smoothstep(0.3, 0.6, value_noise(foot / 5.0) + 0.25 * h3);
    // Far tufts shrink away before the grid's edge, so its border never shows.
    float reach = float(half_grid) * u_spacing;
    float fade = 1.0 - smoothstep(reach * 0.6, reach * 0.95, distance(foot, u_camera_position.xz));
    float size = (covered > 0.5 || downtown) ? 0.0 : patches * fade;
    float height = mix(0.15, 0.40, h3) * size;
    float width = (0.8 + 0.6 * h2) * size;

    // TURN, SIZE, BEND. Each tuft turned its own way; the tip pushed by the wind (a
    // third of what bends a crown: blades are short) and a quicker shiver of its own.
    float turn = h1 * 6.2832;
    vec2 cs = vec2(cos(turn), sin(turn));
    vec3 p = vec3(a_position.x * cs.x - a_position.z * cs.y, a_position.y, a_position.x * cs.y + a_position.z * cs.x);
    p.xz *= width;
    p.y *= height;
    vec2 bend = wind_offset(foot, u_time) * 0.35 + wind_direction * 0.03 * sin(u_time * 5.0 + h2 * 40.0);
    p.xz += bend * a_emissive * a_emissive * size;  // the foot stays, the tip bends most
    vec3 world = vec3(foot.x, 0.0, foot.y) + p;

    // ITS COLOR follows the ground's under it (the same noise), a little brighter at the
    // tip, a little drier where the ground is dry.
    float mid = value_noise(foot / 6.5);
    float dry = smoothstep(0.62, 0.88, value_noise(foot / 23.0)) * 0.5;
    vec3 green = mix(vec3(0.82), vec3(1.12), mid);
    v_color = mix(a_color * green, vec3(0.55, 0.53, 0.28), dry);
    v_normal = a_normal;
    v_world_position = world;
    v_emissive = 0.0;
    v_tint = vec3(1.0);
    gl_Position = u_view_projection * vec4(world, 1.0);
    // Cut at a plane while the city is drawn for a window indoors (the vertex header,
    // render/shader.cpp); nothing at any other time.
    CLIP_WORLD(world);
}
