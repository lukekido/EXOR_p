// bloom_down.frag: a picture half as wide and half as tall as the one it reads
// (render/bloom.cpp). Four bilinear taps around the pixel, each the average of four
// texels, so sixteen texels in all: shrinking this way never skips a small light (a
// window two pixels wide still counts, just dimmer).
//
// The first pass reads the frame itself and keeps only what glows: the color times
// flat.frag's glow mark in the alpha (the lit windows, the lamps, the signs, the
// headlights). Everything else is black there, so only the lights bloom, never a white
// wall in the sun.

in vec2 v_uv;

uniform sampler2D u_source;
uniform vec2 u_texel;      // one texel of the source, in 0..1 units
uniform float u_mask;      // 1: keep color x alpha (the first pass); 0: keep the color as it is

out vec4 frag_color;

vec3 tap(vec2 uv) {
    vec4 c = texture(u_source, uv);
    return mix(c.rgb, c.rgb * c.a, u_mask);
}

void main() {
    vec3 sum = tap(v_uv + u_texel * vec2(-1.0, -1.0)) + tap(v_uv + u_texel * vec2(1.0, -1.0)) +
               tap(v_uv + u_texel * vec2(-1.0, 1.0)) + tap(v_uv + u_texel * vec2(1.0, 1.0));
    frag_color = vec4(sum * 0.25, 1.0);
}
