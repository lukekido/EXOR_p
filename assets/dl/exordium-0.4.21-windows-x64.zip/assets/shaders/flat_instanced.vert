// flat_instanced.vert: flat.vert for INSTANCED drawing (used with flat.frag).
//
// Hundreds of cars share one mesh. Drawing them one by one means hundreds of draw calls,
// each with its own uniforms (u_model, u_tint): the CPU and the driver spend more time
// talking than the GPU spends drawing. With instancing, the game puts every car's
// transform and color into one buffer and asks for the mesh "N times" in ONE call
// (glDrawElementsInstanced). The attributes below marked "per instance" advance once per
// copy instead of once per vertex (glVertexAttribDivisor = 1, see render/mesh.cpp).

layout(location = 0) in vec3 a_position;
layout(location = 1) in vec3 a_normal;
layout(location = 2) in vec3 a_color;
layout(location = 3) in float a_emissive;
// Per instance: where this copy is (a mat4 takes four attribute slots, one per
// column), its color, and whether its lights are on (multiplies the emissive).
layout(location = 4) in mat4 a_model;
layout(location = 8) in vec3 a_tint;
layout(location = 9) in float a_glow;

uniform mat4 u_view_projection;

out vec3 v_color;
out vec3 v_normal;
out vec3 v_world_position;
out float v_emissive;
out vec3 v_tint;

void main() {
    vec4 world = a_model * vec4(a_position, 1.0);
    v_world_position = world.xyz;
    v_normal = mat3(a_model) * a_normal;
    v_color = a_color;
    v_emissive = a_emissive * a_glow;
    v_tint = a_tint;
    gl_Position = u_view_projection * world;
    // Cut at a plane while the city is drawn for a window indoors (the vertex header,
    // render/shader.cpp); nothing at any other time.
    CLIP_WORLD(world.xyz);
}
