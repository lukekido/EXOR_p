// sky.vert: ONE TRIANGLE TO RULE THEM ALL. It is bigger than the screen ON PURPOSE:
// the overhang dangles past the edges, the GPU clips it for free, and every pixel
// gets painted exactly once. Never measure anything, just make it enormous. No
// "#version": the game adds it.
//
// There is no vertex buffer here. NONE. The entire geometry department is
// gl_VertexID (0, 1, 2) picking the corners (-1,-1), (3,-1) and (-1,3) straight out
// of thin air -- fitting, since this triangle is itself mostly thin air. Three
// vertices, zero bytes of vertex data: minimalism as a lifestyle, and honestly,
// hard to argue with the results.

out vec2 v_ndc;  // THE CARGO MANIFEST: two floats, one position, from -1 to 1.
                 // Travel light; the sky already carries enough weight as it is.

void main() {
    // THE ENTIRE MESH PIPELINE, EVERYBODY: two ternaries. Corner selection by vertex
    // ID -- allocation-free, branchless, and perfectly legible on a slow afternoon.
    vec2 corner = vec2(gl_VertexID == 1 ? 3.0 : -1.0, gl_VertexID == 2 ? 3.0 : -1.0);
    v_ndc = corner;
    // No buffer, no fetch, no state, no dependencies: nothing in this function can
    // fail, which by this game's standards makes it practically royalty.
    gl_Position = vec4(corner, 0.0, 1.0);
}
