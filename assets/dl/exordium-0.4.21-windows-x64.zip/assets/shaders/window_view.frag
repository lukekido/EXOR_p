// window_view.frag: an interior's window pane that shows the open world.
//
// The game has just drawn the city, in this same frame, from the eye of whoever looks
// through the window, carried into the real building (game/window_views.cpp): the same
// lens, the same picture size, the city cut at the facade so that nothing of the
// building's inside hides the street. Seen through the pane, a point of that picture lies
// exactly behind the pixel the pane covers: so each pixel of the pane is simply the same
// pixel of the picture. No guessing of depths, no stretching: what a hole in the wall
// would show, with its true parallax, from anywhere in the room.

uniform sampler2D u_view;     // the city through this wall's windows, this frame
uniform float u_glow_share;   // the halos' share outdoors, over indoors (see below)

out vec4 frag_color;

void main() {
    vec4 city = texelFetch(u_view, ivec2(gl_FragCoord.xy), 0);
    // The alpha carries the glow marks the halos (bloom) grow from. Indoors the halos are
    // at full strength (the ceiling lamps); outdoors only as the night falls. Scaled by
    // the share, the street's lamps and lit windows glow through the glass exactly as much
    // as they do outside, and not at all at noon.
    frag_color = vec4(city.rgb, city.a * u_glow_share);
}
