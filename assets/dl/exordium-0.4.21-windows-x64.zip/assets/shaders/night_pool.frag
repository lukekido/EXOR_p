// night_pool.frag: light pools from the street lamps, the traffic lights and the lit
// windows and shop fronts, faked the same way as the headlight pools (light_pool.frag),
// which already worked well on the cars.
//
// No light is computed. Each pool is a flat square lying where the light lands, and
// this shader paints a soft glow on it that the game ADDS to the color already on screen
// (additive blending). Dark asphalt under a lamp gets a warm disc, a sidewalk in front
// of a shop gets the shop's light, with nothing more than a few pixels of arithmetic.

in vec2 v_pool;
in vec3 v_light;
in float v_strength;
in vec3 v_world_position;

uniform float u_strength;        // 0 by day, 1 at night (the lighting's window glow)
uniform vec3 u_camera_position;
uniform vec2 u_fog_range;

out vec4 frag_color;

void main() {
    float light;
    if (v_strength >= 0.0) {
        // A round pool: full under the lamp, fading to nothing at the square's inscribed
        // circle. smoothstep keeps a broad bright core and a soft rim, so the pool reads
        // as a disc of light from the street, not a faint smudge.
        float d = length(v_pool);
        light = 1.0 - smoothstep(0.0, 1.0, d);
    } else {
        // A spill: brightest at the wall (x = -1), fading smoothly to nothing at the
        // far edge; soft at the sides like the window it comes from.
        float out_from_wall = (v_pool.x + 1.0) * 0.5;
        float lengthwise = 1.0 - smoothstep(0.0, 1.0, out_from_wall);
        float sideways = 1.0 - smoothstep(0.55, 1.0, abs(v_pool.y));
        light = lengthwise * sideways;
    }
    light *= abs(v_strength) * u_strength;
    // Far away the fog swallows it, like everything else.
    float fog = smoothstep(u_fog_range.x, u_fog_range.y, distance(v_world_position, u_camera_position));
    frag_color = vec4(v_light * light * (1.0 - fog), 0.0);  // alpha 0: a pool adds no glow mark (flat.frag)
}
