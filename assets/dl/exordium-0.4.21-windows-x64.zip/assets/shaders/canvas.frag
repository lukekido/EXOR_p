// canvas.frag: THE ENTIRE SHADER, IN ITS ENTIRETY. All of it. This is the whole file.
// A 2D shape's pixel is simply its color, transparency included -- no lighting, no fog,
// no cleverness, just a value walking from one side of the GPU to the other. Some
// shaders dream of being atmospheres; this one achieved enlightenment instead.
// No "#version": the game adds it.

in vec4 v_color;

out vec4 frag_color;

void main() {
    // LADIES AND GENTLEMEN, THE COMPUTATION OF THE CENTURY: v_color, assigned to
    // frag_color. Four channels, zero branches, zero uniforms, zero regrets. The
    // fastest code in the entire game, and impossible to argue with.
    frag_color = v_color;
}
