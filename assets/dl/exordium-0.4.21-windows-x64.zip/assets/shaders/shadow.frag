// shadow.frag: THE SUN'S CAMERA KEEPS NO COLORS. While the city is drawn from the sun
// (render/shadow_map.hpp), only the depth of each pixel matters: how far from the sun
// the first thing it meets is. The GPU writes that by itself, so this stage has nothing
// to add and no color to give. It pairs with flat.vert and flat_instanced.vert, so the
// wind still sways the crowns and the faces fold away exactly as in the frame: the
// shadow moves with what casts it. No "#version" line: the game adds it.

void main() {
}
