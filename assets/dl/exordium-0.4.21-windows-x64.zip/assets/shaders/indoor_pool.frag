// indoor_pool.frag: a soft disc of light on an interior's floor, under each ceiling lamp.
//
// The same fake as the city's night pools (night_pool.frag): no light is computed, the
// glow is ADDED to the floor already on screen (additive blending), brightest right under
// the lamp and fading to nothing at the pool's radius. A pool cut by a wall keeps fading
// as the whole disc would, because the corners carry their distance from the lamp.

in vec2 v_pool;
in vec3 v_light;
in float v_strength;

out vec4 frag_color;

void main() {
    float d = length(v_pool);
    // A broad core and a soft rim (smoothstep), squared toward the edge so the rim melts
    // into the room's own light instead of drawing a ring.
    float light = 1.0 - smoothstep(0.0, 1.0, d);
    light *= light;
    frag_color = vec4(v_light * light * v_strength, 0.0);  // alpha 0: no glow mark (flat.frag)
}
