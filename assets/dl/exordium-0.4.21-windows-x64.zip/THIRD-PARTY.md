# EXORDIUM: credits and licenses

<!-- author's note -->
I left this document in Claude's hands, since I nearly unalived from the sheer 
boredom of writing down everything I could (and should) give credit for. I even
avoided using AI images purely because I was too lazy to credit them afterwards (and to avoid
being hated by half the planet for using them 😄😄😄). That also explains the game's shitty
graphics! Well, Claude, this document is yours from here on! Over and out!

**Copy that.** Claude here, taking the radio. I'll keep it short: the people below wrote
software that works, and the least we can do is credit them for their great job and
not bore you on their behalf.
<!-- /author's note -->

## The short version

For anyone reading this with a publisher's hat on:

- **Code from other people:** Six libraries. Five are free and open source, under
  permissive licenses (zlib, MIT, public domain, Apache 2.0). The sixth is Valve's Steam
  library, under Valve's own agreement.
- **Fonts:** two, both from Google's Noto family, both under the SIL Open Font License
  1.1. Their license texts ship right next to them, in `assets/fonts/`.
- **Art and sound:** made for this game. **No AI-generated images, textures or other art
  ship with it.** The city, the cars, the people and the furniture are currently built by the
  game's own code out of shapes and colors; the sounds are synthesized by the game's own
  code too; the only two pictures (the TV Maresol logo and the flag of SPRF) were drawn
  on ArtCraft's PhotoCraft 19.2. Which, yes, explains the graphics. We stand by them. Mostly.
- **The full license texts** are at the bottom of this file, in "The fine print".

## The libraries

### SDL3 (3.4.18)

SDL3 opens the window, reads your keyboard, mouse and controller, and plays the sound. If
the game were a body, SDL would be most of its nervous system, and Luke is especially thankful
for not having to deal with Windows API calls to do all this by himself.

- **By:** Sam Lantinga and the SDL contributors
- **License:** zlib
- **Link:** <https://libsdl.org>

### GLM (1.0.3)

GLM does the math. Every time something in the game moves, turns, falls or gets run over
(sorry), GLM did the arithmetic first. Luke was reluctant to use it fully, but after
some clarifications here and there — and the awful experience of trying to program ragdoll physics
by himself — he finally surrendered to the 21st century and accepted that GLM was the smartpants move he
needed to make the game feel the way he wanted.

- **By:** G-Truc Creation
- **License:** MIT. GLM also offers the "Happy Bunny License", which asks you not to use
  it for military purposes. We went with MIT, but for the record: the game has no
  military purposes, and the bunny remains happy.
- **Link:** <https://github.com/g-truc/glm>

### Dear ImGui (1.92.9b)

The developer of this project is a degenerate game cheater and, as you may know, Dear ImGui
draws simple windows with nice buttons and sliders, which is why Luke chose it for the game's
developer tools — accessible in debug builds by hitting the F11 key. If you never press F11
you'll never meet it, but it lives inside the executable, so it gets its credit for saving
HUNDREDS or even THOUSANDS of hours of writing and running Python scripts to pull debug
results from. Luke is kinda stubborn about new methods of modular debugging; he still relies
on deep dives into full test cycles, like the Aztecs did, and Dear ImGui does the job for
Luke's weird little soft spot for those tests. For real, in his own words, he LIKES doing it,
like a stress-relieving thing. Well, I'm not here to judge! You are free to!

- **By:** Omar Cornut and the Dear ImGui contributors
- **License:** MIT
- **Link:** <https://github.com/ocornut/imgui>

### stb_truetype (v1.26)

stb_truetype turns the font files into the letters you read on screen. The developer even
got emotional when he knew this one file, written by one person, is quietly inside a remarkable
number of games 😅.

- **By:** Sean Barrett
- **License:** public domain or MIT, whichever you prefer (both texts are below)
- **Link:** <https://github.com/nothings/stb>

### glad (2.0.8)

glad is a code generator. Run once, it wrote the small piece of the game that, at startup,
asks your graphics driver where its OpenGL drawing functions are. Unglamorous, essential
for low-level work like this. Much appreciated.
And yes, any "glad" puns were avoided here.

- **By:** David Herberth and the glad contributors
- **License:** the generated code is public domain (WTFPL or CC0-1.0). The function and
  constant definitions inside it come from the OpenGL API Registry, Copyright 2013-2020
  The Khronos Group Inc., under the Apache License 2.0. Its `khrplatform.h` header is
  Copyright 2008-2018 The Khronos Group Inc., under an MIT-style license. Both texts are
  below.
- **Link:** <https://github.com/Dav1dde/glad>

### Steam API (Steamworks SDK 1.65)

Valve's library, the `steam_api64.dll` file next to the game. The game uses it for Steam
features when it runs on Steam.

- **By:** Valve Corporation
- **License:** the Steamworks SDK Access Agreement (Valve's terms, not open source).
  Valve lets games ship this library with them.
- **Link:** <https://partner.steamgames.com>

## The fonts

### Noto Sans (Regular, version 2.015)

The font used on every menu, message and e-mail in the game.

- **By:** the Noto Project Authors (Google)
- **License:** SIL Open Font License 1.1; full text in `assets/fonts/OFL-NotoSans.txt`
- **Link:** <https://notofonts.github.io>

### Noto Sans JP (Regular, version 2.004)

The Japanese characters, for whenever the text needs them (yup! Dev is a weabooo).

- **By:** Google and Adobe (the Noto CJK project)
- **License:** SIL Open Font License 1.1; full text in `assets/fonts/OFL-NotoSansJP.txt`
- **Link:** <https://github.com/notofonts/noto-cjk>

## What the licenses ask, in plain words

- **zlib** (SDL3): use it for anything, commercial games included. Don't claim you wrote
  it, and mark altered versions as altered. Credit is appreciated but not required; it's
  given here anyway, gladly, no cap.
- **MIT** (GLM, Dear ImGui, stb_truetype, Khronos's `khrplatform.h`): use it for
  anything; keep the copyright and license notice with every copy. That's what "The fine
  print" below is for.
- **Public domain** (stb_truetype, glad's generated code): no conditions at all. Thanks
  anyway.
- **Apache 2.0** (Khronos's OpenGL definitions inside glad): use it for anything; give
  everyone who gets the game a copy of the license. It's below, all of it.
- **SIL Open Font License 1.1** (both fonts): free to use and ship with a game,
  commercial or not. The license text must travel with the font files (it does, in the
  same folder), and the fonts can't be sold on their own.
- **Steamworks SDK Access Agreement** (Steam API): Valve's terms. Valve allows games to
  ship this library; it's the only part of Valve's SDK that comes with the game.

That's all folks! Thanks to all of them, and thank you for reading a license file of your
own free will: you are a rare and wonderful person, and Luke would probably like to have
you as one of his Steam friends because who the hell reads those documents? This MF claims
he does and, although I do not believe him 100% on this (he is probably using some Gemini 
shit to summarize it — he can't be real, not in 2026!), he speaks like a smartass who would
love to chat about legal stuff or whatever weird folks like you do.

## The fine print

The notices the licenses ask to travel with the game, word for word.

### SDL3: zlib License

```text
Copyright (C) 1997-2026 Sam Lantinga <slouken@libsdl.org>

This software is provided 'as-is', without any express or implied
warranty.  In no event will the authors be held liable for any damages
arising from the use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it
freely, subject to the following restrictions:

1. The origin of this software must not be misrepresented; you must not
   claim that you wrote the original software. If you use this software
   in a product, an acknowledgment in the product documentation would be
   appreciated but is not required.
2. Altered source versions must be plainly marked as such, and must not be
   misrepresented as being the original software.
3. This notice may not be removed or altered from any source distribution.
```

### GLM: MIT License

```text
Copyright (c) 2005 - G-Truc Creation

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
```

### Dear ImGui: MIT License

```text
The MIT License (MIT)

Copyright (c) 2014-2026 Omar Cornut

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

### stb_truetype: MIT License or Public Domain

```text
This software is available under 2 licenses -- choose whichever you prefer.
------------------------------------------------------------------------------
ALTERNATIVE A - MIT License
Copyright (c) 2017 Sean Barrett
Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies
of the Software, and to permit persons to whom the Software is furnished to do
so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
------------------------------------------------------------------------------
ALTERNATIVE B - Public Domain (www.unlicense.org)
This is free and unencumbered software released into the public domain.
Anyone is free to copy, modify, publish, use, compile, sell, or distribute this
software, either in source code form or as a compiled binary, for any purpose,
commercial or non-commercial, and by any means.
In jurisdictions that recognize copyright laws, the author or authors of this
software dedicate any and all copyright interest in the software to the public
domain. We make this dedication for the benefit of the public at large and to
the detriment of our heirs and successors. We intend this dedication to be an
overt act of relinquishment in perpetuity of all present and future rights to
this software under copyright law.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
```

### glad: Khronos `khrplatform.h` (MIT-style license)

```text
Copyright (c) 2008-2018 The Khronos Group Inc.

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and/or associated documentation files (the
"Materials"), to deal in the Materials without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Materials, and to
permit persons to whom the Materials are furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be included
in all copies or substantial portions of the Materials.

THE MATERIALS ARE PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
MATERIALS OR THE USE OR OTHER DEALINGS IN THE MATERIALS.
```

### glad: the OpenGL API Registry (Apache License 2.0)

The OpenGL function and constant definitions in the game's loader come from the OpenGL
API Registry: Copyright 2013-2020 The Khronos Group Inc., SPDX-License-Identifier:
Apache-2.0. The license, in full:

```text
                                 Apache License
                           Version 2.0, January 2004
                        http://www.apache.org/licenses/

   TERMS AND CONDITIONS FOR USE, REPRODUCTION, AND DISTRIBUTION

   1. Definitions.

      "License" shall mean the terms and conditions for use, reproduction,
      and distribution as defined by Sections 1 through 9 of this document.

      "Licensor" shall mean the copyright owner or entity authorized by
      the copyright owner that is granting the License.

      "Legal Entity" shall mean the union of the acting entity and all
      other entities that control, are controlled by, or are under common
      control with that entity. For the purposes of this definition,
      "control" means (i) the power, direct or indirect, to cause the
      direction or management of such entity, whether by contract or
      otherwise, or (ii) ownership of fifty percent (50%) or more of the
      outstanding shares, or (iii) beneficial ownership of such entity.

      "You" (or "Your") shall mean an individual or Legal Entity
      exercising permissions granted by this License.

      "Source" form shall mean the preferred form for making modifications,
      including but not limited to software source code, documentation
      source, and configuration files.

      "Object" form shall mean any form resulting from mechanical
      transformation or translation of a Source form, including but
      not limited to compiled object code, generated documentation,
      and conversions to other media types.

      "Work" shall mean the work of authorship, whether in Source or
      Object form, made available under the License, as indicated by a
      copyright notice that is included in or attached to the work
      (an example is provided in the Appendix below).

      "Derivative Works" shall mean any work, whether in Source or Object
      form, that is based on (or derived from) the Work and for which the
      editorial revisions, annotations, elaborations, or other modifications
      represent, as a whole, an original work of authorship. For the purposes
      of this License, Derivative Works shall not include works that remain
      separable from, or merely link (or bind by name) to the interfaces of,
      the Work and Derivative Works thereof.

      "Contribution" shall mean any work of authorship, including
      the original version of the Work and any modifications or additions
      to that Work or Derivative Works thereof, that is intentionally
      submitted to Licensor for inclusion in the Work by the copyright owner
      or by an individual or Legal Entity authorized to submit on behalf of
      the copyright owner. For the purposes of this definition, "submitted"
      means any form of electronic, verbal, or written communication sent
      to the Licensor or its representatives, including but not limited to
      communication on electronic mailing lists, source code control systems,
      and issue tracking systems that are managed by, or on behalf of, the
      Licensor for the purpose of discussing and improving the Work, but
      excluding communication that is conspicuously marked or otherwise
      designated in writing by the copyright owner as "Not a Contribution."

      "Contributor" shall mean Licensor and any individual or Legal Entity
      on behalf of whom a Contribution has been received by Licensor and
      subsequently incorporated within the Work.

   2. Grant of Copyright License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      copyright license to reproduce, prepare Derivative Works of,
      publicly display, publicly perform, sublicense, and distribute the
      Work and such Derivative Works in Source or Object form.

   3. Grant of Patent License. Subject to the terms and conditions of
      this License, each Contributor hereby grants to You a perpetual,
      worldwide, non-exclusive, no-charge, royalty-free, irrevocable
      (except as stated in this section) patent license to make, have made,
      use, offer to sell, sell, import, and otherwise transfer the Work,
      where such license applies only to those patent claims licensable
      by such Contributor that are necessarily infringed by their
      Contribution(s) alone or by combination of their Contribution(s)
      with the Work to which such Contribution(s) was submitted. If You
      institute patent litigation against any entity (including a
      cross-claim or counterclaim in a lawsuit) alleging that the Work
      or a Contribution incorporated within the Work constitutes direct
      or contributory patent infringement, then any patent licenses
      granted to You under this License for that Work shall terminate
      as of the date such litigation is filed.

   4. Redistribution. You may reproduce and distribute copies of the
      Work or Derivative Works thereof in any medium, with or without
      modifications, and in Source or Object form, provided that You
      meet the following conditions:

      (a) You must give any other recipients of the Work or
          Derivative Works a copy of this License; and

      (b) You must cause any modified files to carry prominent notices
          stating that You changed the files; and

      (c) You must retain, in the Source form of any Derivative Works
          that You distribute, all copyright, patent, trademark, and
          attribution notices from the Source form of the Work,
          excluding those notices that do not pertain to any part of
          the Derivative Works; and

      (d) If the Work includes a "NOTICE" text file as part of its
          distribution, then any Derivative Works that You distribute must
          include a readable copy of the attribution notices contained
          within such NOTICE file, excluding those notices that do not
          pertain to any part of the Derivative Works, in at least one
          of the following places: within a NOTICE text file distributed
          as part of the Derivative Works; within the Source form or
          documentation, if provided along with the Derivative Works; or,
          within a display generated by the Derivative Works, if and
          wherever such third-party notices normally appear. The contents
          of the NOTICE file are for informational purposes only and
          do not modify the License. You may add Your own attribution
          notices within Derivative Works that You distribute, alongside
          or as an addendum to the NOTICE text from the Work, provided
          that such additional attribution notices cannot be construed
          as modifying the License.

      You may add Your own copyright statement to Your modifications and
      may provide additional or different license terms and conditions
      for use, reproduction, or distribution of Your modifications, or
      for any such Derivative Works as a whole, provided Your use,
      reproduction, and distribution of the Work otherwise complies with
      the conditions stated in this License.

   5. Submission of Contributions. Unless You explicitly state otherwise,
      any Contribution intentionally submitted for inclusion in the Work
      by You to the Licensor shall be under the terms and conditions of
      this License, without any additional terms or conditions.
      Notwithstanding the above, nothing herein shall supersede or modify
      the terms of any separate license agreement you may have executed
      with Licensor regarding such Contributions.

   6. Trademarks. This License does not grant permission to use the trade
      names, trademarks, service marks, or product names of the Licensor,
      except as required for reasonable and customary use in describing the
      origin of the Work and reproducing the content of the NOTICE file.

   7. Disclaimer of Warranty. Unless required by applicable law or
      agreed to in writing, Licensor provides the Work (and each
      Contributor provides its Contributions) on an "AS IS" BASIS,
      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
      implied, including, without limitation, any warranties or conditions
      of TITLE, NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A
      PARTICULAR PURPOSE. You are solely responsible for determining the
      appropriateness of using or redistributing the Work and assume any
      risks associated with Your exercise of permissions under this License.

   8. Limitation of Liability. In no event and under no legal theory,
      whether in tort (including negligence), contract, or otherwise,
      unless required by applicable law (such as deliberate and grossly
      negligent acts) or agreed to in writing, shall any Contributor be
      liable to You for damages, including any direct, indirect, special,
      incidental, or consequential damages of any character arising as a
      result of this License or out of the use or inability to use the
      Work (including but not limited to damages for loss of goodwill,
      work stoppage, computer failure or malfunction, or any and all
      other commercial damages or losses), even if such Contributor
      has been advised of the possibility of such damages.

   9. Accepting Warranty or Additional Liability. While redistributing
      the Work or Derivative Works thereof, You may choose to offer,
      and charge a fee for, acceptance of support, warranty, indemnity,
      or other liability obligations and/or rights consistent with this
      License. However, in accepting such obligations, You may act only
      on Your own behalf and on Your sole responsibility, not on behalf
      of any other Contributor, and only if You agree to indemnify,
      defend, and hold each Contributor harmless for any liability
      incurred by, or claims asserted against, such Contributor by reason
      of your accepting any such warranty or additional liability.

   END OF TERMS AND CONDITIONS
```

### The fonts: SIL Open Font License 1.1

The full license texts ship next to the fonts, in `assets/fonts/OFL-NotoSans.txt` and
`assets/fonts/OFL-NotoSansJP.txt`, as the license asks.
